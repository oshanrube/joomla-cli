ALTER TABLE `#__airportshuttle` ADD `params` VARCHAR(1024) NOT NULL DEFAULT '';

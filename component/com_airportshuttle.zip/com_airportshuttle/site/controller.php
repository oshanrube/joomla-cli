<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted access');
 
// import Joomla controller library
jimport('joomla.application.component.controller');
 
/**
 * Airport Shuttle Component Controller
 */
class AirportShuttleController extends JController
{
}
